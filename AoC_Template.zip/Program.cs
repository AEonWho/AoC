﻿var lines = File.ReadAllLines("Input.txt").ToList();

for (int i = 0; i < lines.Count; i++)
{
    var line = lines[i];
    var splitted = line.Split(' ');
}